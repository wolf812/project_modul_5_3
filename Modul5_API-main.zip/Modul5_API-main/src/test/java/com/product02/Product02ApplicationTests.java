package com.product02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Product02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
