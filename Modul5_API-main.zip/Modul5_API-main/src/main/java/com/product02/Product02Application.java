package com.product02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Product02Application {

	public static void main(String[] args) {
		SpringApplication.run(Product02Application.class, args);
	}

}
