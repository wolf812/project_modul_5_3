package com.product02.model.entity;

public enum ERoles {
    ROLE_ADMIN, ROLE_USER, ROLE_MODERATOR
}
