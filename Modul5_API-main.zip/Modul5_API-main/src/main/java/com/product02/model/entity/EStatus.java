package com.product02.model.entity;

public enum EStatus {
    WAITING, CONFIRM,DELIVERY,SUCCESS,CANCEL,DENIED
}
